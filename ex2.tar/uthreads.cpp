#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <csetjmp>
#include <cstring>
#include <queue>
#include <list>
#include <stack>
#include <sys/time.h>
#include <unordered_map>
#include <set>
#include <iostream>
#include "uthreads.h"

#ifdef __x86_64__
/* code for 64 bit Intel arch */

typedef unsigned long address_t;
#define JB_SP 6
#define JB_PC 7

/* A translation is required when using an address of a variable.
   Use this as a black box in your code. */
address_t translate_address (address_t addr)
{
    address_t ret;
    asm volatile("xor    %%fs:0x30,%0\n"
                 "rol    $0x11,%0\n"
            : "=g" (ret)
            : "0" (addr));
    return ret;
}

#else
/* code for 32 bit Intel arch */

typedef unsigned int address_t;
#define JB_SP 4
#define JB_PC 5


/* A translation is required when using an address of a variable.
   Use this as a black box in your code. */
address_t translate_address(address_t addr)
{
    address_t ret;
    asm volatile("xor    %%gs:0x18,%0\n"
                 "rol    $0x9,%0\n"
    : "=g" (ret)
    : "0" (addr));
    return ret;
}


#endif



enum State
{
    READY, RUNNING, BLOCKED
};

typedef struct thread
{
    int id;
    State state;
    char* stack;
    sigjmp_buf env;
    int quantums;
    int sleep_quantums;
    int sleeping_and_blocked;
} thread;

sigset_t signals;

int current_thread = 0;
int total_quantum_usecs;
int quantum_usecs_global; // Global variable to store quantum_usecs
struct itimerval timer;
struct sigaction sa;
//masking signals;

void timer_handler (int sig);
void update_sleeping_threads ();

std::list<thread *> ready_queue;
std::set<int> available_ids;
std::unordered_map<int, thread> threads;
std::unordered_map<int, thread *> sleeping_threads;


void setup_timer ()
{
    timer.it_value.tv_sec = quantum_usecs_global / 1000000;
    timer.it_value.tv_usec = quantum_usecs_global % 1000000;
    timer.it_interval.tv_sec = quantum_usecs_global / 1000000;
    timer.it_interval.tv_usec = quantum_usecs_global % 1000000;

//    if (setitimer (ITIMER_VIRTUAL, &timer, NULL) < 0)
//    {
//        fprintf (stderr, "system error: setitimer error\n");
//        //TODO check if should be -1 instead of exit(1)
//        for (auto &t : threads)
//        {
//            if (t.first != 0)
//            {
//                free(t.second.stack);
//            }
//        }
//        exit(1);
//    }
}



void schedule ()
{
    int prev_thread = current_thread;
    threads[current_thread].state = READY;
    ready_queue.push_back (&threads[current_thread]);

    if (!ready_queue.empty ()) {
        thread *next_thread = ready_queue.front();
        ready_queue.pop_front();

        current_thread = next_thread->id;
        // print the current thread quantums
//      printf("Thread %d quantums: %d\n", current_thread, threads[current_thread].quantums);
    }
    threads[current_thread].state = RUNNING;
    threads[current_thread].quantums++;
    if (sigsetjmp(threads[prev_thread].env, 1) == 0)
    {
        siglongjmp (threads[current_thread].env, 1);
    }
}


void schedule_and_reset_timer(){
    setup_timer();
    if (!ready_queue.empty ()) {
        thread *next_thread = ready_queue.front();
        ready_queue.pop_front();
        current_thread = next_thread->id;
    }
    threads[current_thread].state = RUNNING;
    threads[current_thread].quantums++;
    total_quantum_usecs++;

    siglongjmp (threads[current_thread].env, 1);

}

void timer_handler(int sig)
{
    update_sleeping_threads ();  // Update sleeping threads every quantum
    schedule();
    total_quantum_usecs++;

}

void update_sleeping_threads()
{
    //TODO separate to cases about the sleep and the block, if the thread is just sleep.
    for (auto it = sleeping_threads.begin (); it != sleeping_threads.end ();) {
        if (--(it->second->sleep_quantums) == 0) {

//      sleeping_threads.erase(it);
            it->second->sleep_quantums = 0;
            if (it->second->sleeping_and_blocked == 0) {
                it->second->state = READY;
                ready_queue.push_back(it->second);
            }
            // Remove the thread from the sleeping_threads map
            it = sleeping_threads.erase (it);
        }
        else {
            ++it;
        }
    }
}



int uthread_init (int quantum_usecs)
{
    if (quantum_usecs <= 0)
    {
        fprintf (stderr, "thread library error: non-positive quantum_usecs\n");
        return -1;
    }
    quantum_usecs_global = quantum_usecs;
    total_quantum_usecs = 1;

    sa.sa_handler = &timer_handler;
    if (sigaction (SIGVTALRM, &sa, NULL) < 0)
    {
        fprintf (stderr, "system error: sigaction error\n");
        exit(1);
    }

    timer.it_value.tv_sec = quantum_usecs_global / 1000000;
    timer.it_value.tv_usec = quantum_usecs_global % 1000000;
    timer.it_interval.tv_sec = quantum_usecs_global / 1000000;
    timer.it_interval.tv_usec = quantum_usecs_global % 1000000;
    if (setitimer(ITIMER_VIRTUAL, &timer, NULL) < 0)
    {
        std::cerr<< "system error: setting timer failed" <<std::endl;
        exit(1);
    }
    // Initialize signal signals
    sigemptyset(&signals);
    sigaddset(&signals, SIGVTALRM);
    threads[0] = {0, RUNNING, NULL, {}, 1, 0,0};
    sigsetjmp(threads[0].env, 1);

    return 0;
}

int uthread_spawn (thread_entry_point entry_point)
{
    // Block signals
    sigprocmask(SIG_BLOCK, &signals, NULL);
    if (entry_point == NULL)
    {
        fprintf (stderr, "thread library error: null entry_point\n");
        return -1;
    }

    // Ensure the total number of threads does not exceed MAX_THREAD_NUM
    if (threads.size () >= MAX_THREAD_NUM )
    {
        fprintf (stderr, "thread library error: exceeded maximum number of threads\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }
    int tid;
    if (!available_ids.empty ())
    {
        auto it = available_ids.begin ();
        tid = *it;
        available_ids.erase (it);
    }
    else
    {
        tid = (int)threads.size ();
    }

    char* stack = (char*)calloc (STACK_SIZE, sizeof (char));
    if(!stack){
        fprintf (stderr,"System error: invalid memory allocation\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        for (auto &t : threads)
        {
            if (t.first != 0)
            {
                free(t.second.stack);
            }
        }
        exit(1);
    }
    threads[tid] = {tid, READY, stack, {}, 0, 0,0};

    auto sp = (address_t)threads[tid].stack + STACK_SIZE - sizeof(address_t);
    auto pc = (address_t) entry_point;

    sigsetjmp(threads[tid].env, 1);
    (threads[tid].env->__jmpbuf)[JB_SP] = translate_address (sp);
    (threads[tid].env->__jmpbuf)[JB_PC] = translate_address (pc);
    sigemptyset (&threads[tid].env->__saved_mask);

    ready_queue.push_back (&threads[tid]);

    // Unblock signals
    sigprocmask(SIG_UNBLOCK, &signals, NULL);

    return tid;
}

int uthread_terminate (int tid)
{
// Block signals
    sigprocmask(SIG_BLOCK, &signals, NULL);

    auto it = threads.find (tid);
    if (it == threads.end())
    {
        fprintf (stderr, "thread library error: no such thread\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }

    if (tid == 0)
    {
        for (auto &t : threads)
        {
            if (t.first != 0)
            {
                free(t.second.stack);
            }
        }
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        exit (0);
    }

    thread& cur_thread = threads[tid];
    if (cur_thread.state == READY)
    {
        ready_queue.remove_if ([tid] (thread *t)
                               { return t->id == tid; });
    }

    if (cur_thread.sleep_quantums > 0)
    {
        sleeping_threads.erase(tid);
    }

    // Free the allocated stack memory
    free(cur_thread.stack);
    cur_thread.stack = nullptr;

    threads.erase(tid);
    available_ids.insert(tid);


    if (tid == current_thread){
        sigprocmask(SIG_UNBLOCK, &signals, NULL);

        schedule_and_reset_timer();
    }
    sigprocmask(SIG_UNBLOCK, &signals, NULL);

    return 0;
}

int uthread_block(int tid)
{
    // Block signals to enter a critical section
    sigprocmask(SIG_BLOCK, &signals, NULL);

    // Check if the thread with the given ID exists
    if (threads.find(tid) == threads.end())
    {
        fprintf(stderr, "thread library error: no such thread\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }

    // Ensure that the main thread (tid == 0) cannot be blocked
    if (tid == 0)
    {
        fprintf(stderr, "thread library error: cannot block main thread\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }

    // Handle the case where the thread is both sleeping and blocked
    if (threads[tid].sleep_quantums > 0)
    {
        threads[tid].sleeping_and_blocked = 1;
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return 0;
    }

    // If the thread is already in the BLOCKED state, do nothing
    if (threads[tid].state == BLOCKED)
    {
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return 0;
    }

    // If the thread is in the READY state, remove it from the ready queue
    if (tid != current_thread && threads[tid].state == READY)
    {
        ready_queue.remove_if([tid](thread *t) { return t->id == tid; });
    }

    // Change the thread's state to BLOCKED
    threads[tid].state = BLOCKED;

    // Unblock signals to leave the critical section
    sigprocmask(SIG_UNBLOCK, &signals, NULL);

    // If the thread blocks itself, schedule the next thread
    if (tid == current_thread)
    {
        if (sigsetjmp(threads[current_thread].env, 1) == 0){
            schedule_and_reset_timer();

        }
    }

    return 0;
}

int uthread_resume(int tid)
{
    // Block signals
    sigprocmask(SIG_BLOCK, &signals, NULL);

    // Check if the thread with the given ID exists
    if (threads.find (tid) == threads.end ())
    {
        fprintf (stderr, "thread library error: no such thread\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }

    // Get a reference to the thread
    thread &t = threads[tid];

    // If the thread is in the RUNNING or READY state, do nothing
    if (t.state == RUNNING || t.state == READY)
    {
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return 0;
    }

    // If the thread is in the BLOCKED state, move it to the READY state and add it to the ready queue
    if (t.state == BLOCKED && t.sleep_quantums == 0){
        t.state = READY;
        ready_queue.push_back (&t);
    }

    if(t.state == BLOCKED && t.sleep_quantums > 0){
        t.sleeping_and_blocked = 0;
    }

    // Unblock signals
    sigprocmask(SIG_UNBLOCK, &signals, NULL);
    return 0;
}

int uthread_sleep (int num_quantums)
{
    sigprocmask(SIG_BLOCK, &signals, NULL);
    //TODO check what to do with this: Specifically,
    // * the quantum of the thread which has made the call to uthread_sleep isn’t counted.
    if (num_quantums <= 0)
    {
        fprintf (stderr, "thread library error: non-positive num_quantums\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }

    // Ensure the main thread (tid == 0) cannot be put to sleep
    if (current_thread == 0)
    {
        fprintf (stderr, "thread library error: cannot put main thread to sleep\n");
        sigprocmask(SIG_UNBLOCK, &signals, NULL);
        return -1;
    }

    // Block the running thread and  it to sleep for the specified number of quantums
    thread &t = threads[current_thread];
    t.sleep_quantums = num_quantums;

    // Move the thread to the sleeping threads list
    sleeping_threads[current_thread] = &t;

    t.state = BLOCKED;
    t.sleeping_and_blocked = 0;

    sigprocmask(SIG_UNBLOCK, &signals, NULL);
    //raise(SIGVTALRM);
    if (sigsetjmp(t.env, 1) == 0)
    {
        schedule_and_reset_timer();
    }
    return 0;
}

int uthread_get_tid() {
    return current_thread;
}

int uthread_get_total_quantums() {
    return total_quantum_usecs;
}

int uthread_get_quantums(int tid) {
    if (threads.find(tid) == threads.end()) {
        fprintf(stderr, "thread library error: no such thread\n");
        return -1;
    }
//  if (tid == threads[tid].id) {
//    return threads[tid].quantums+1;
//  }
    return threads[tid].quantums;
}