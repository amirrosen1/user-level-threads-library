#include <csignal>
#include <csetjmp>
#include <cstring>
#include <cstdio>
#include <queue>
#include <list>
#include <stack>
#include <sys/time.h>
#include <signal.h>
#include <unordered_map>
#include <set>
#include "uthreads.h"

#ifdef __x86_64__
/* code for 64 bit Intel arch */

typedef unsigned long address_t;
#define JB_SP 6
#define JB_PC 7

/* A translation is required when using an address of a variable.
   Use this as a black box in your code. */
address_t translate_address (address_t addr)
{
  address_t ret;
  asm volatile("xor    %%fs:0x30,%0\n"
               "rol    $0x11,%0\n"
      : "=g" (ret)
      : "0" (addr));
  return ret;
}

#else
/* code for 32 bit Intel arch */

typedef unsigned int address_t;
#define JB_SP 4
#define JB_PC 5


/* A translation is required when using an address of a variable.
   Use this as a black box in your code. */
address_t translate_address(address_t addr)
{
    address_t ret;
    asm volatile("xor    %%gs:0x18,%0\n"
                 "rol    $0x9,%0\n"
    : "=g" (ret)
    : "0" (addr));
    return ret;
}


#endif

const int TIMER_INTERVAL_USEC = 100000; // 100 milliseconds or 0.1 seconds

enum State
{
    READY, RUNNING, BLOCKED
};

typedef struct thread
{
    int id;
    State state;
    char stack[STACK_SIZE];
    sigjmp_buf env;
    //TODO check if running quantums and check if should be int
    int quantums;
    int sleep_quantums;
} thread;

int current_thread = 0;
int total_quantum_usecs;
int quantum_usecs_global; // Global variable to store quantum_usecs


struct itimerval timer;
struct sigaction sa;
void timer_handler (int sig);
void update_sleeping_threads ();

std::list<thread *> ready_queue;
std::set<int> available_ids;
std::unordered_map<int, thread> threads;
std::unordered_map<int, thread *> sleeping_threads; // Maps thread IDs to remaining sleep quantums

void setup_timer ()
{
  sa.sa_handler = timer_handler;
  if (sigaction (SIGVTALRM, &sa, NULL) < 0)
  {
    fprintf (stderr, "system error: sigaction error\n");
    exit (1);
  }

  timer.it_value.tv_sec = quantum_usecs_global / 1000000;
  timer.it_value.tv_usec = quantum_usecs_global % 1000000;
  timer.it_interval.tv_sec = quantum_usecs_global / 1000000;
  timer.it_interval.tv_usec = quantum_usecs_global % 1000000;

  if (setitimer (ITIMER_VIRTUAL, &timer, NULL))
  {
    fprintf (stderr, "system error: setitimer error\n");
    exit (1);
  }
}

void schedule ()
{
  if (!ready_queue.empty ())
  {
    thread *next_thread = ready_queue.front ();
    ready_queue.pop_front ();
    int tid = current_thread;
    current_thread = next_thread->id;
    threads[current_thread].state = RUNNING;
    total_quantum_usecs++;
    threads[current_thread].quantums++;
    if (sigsetjmp(threads[tid].env, 1) == 0)
    {
      siglongjmp (threads[current_thread].env, 1);
    }
  }
  setup_timer ();
}

void timer_handler (int sig)
{
  update_sleeping_threads ();  // Update sleeping threads every quantum

  if (threads[current_thread].state == RUNNING)
  {
    threads[current_thread].state = READY;
    ready_queue.push_back (&threads[current_thread]);
  }
  schedule ();
}

void update_sleeping_threads ()
{
  //TODO separate to cases about the sleep and the block, if the thread is just sleep.
  for (auto it = sleeping_threads.begin (); it != sleeping_threads.end ();)
    // Decrement the sleep_quantums for the current thread
    if (--(it->second->sleep_quantums) <= 0)
    {
      int tid = it->second->id;

      // Remove the thread from the sleeping_threads map
      it = sleeping_threads.erase (it);
      threads[tid].sleep_quantums = 0;
    }
    else
    {
      ++it;
    }
}

int uthread_init (int quantum_usecs)
{
  if (quantum_usecs <= 0)
  {
    fprintf (stderr, "thread library error: non-positive quantum_usecs\n");
    return -1;
  }

  quantum_usecs_global = quantum_usecs;


//  sa.sa_handler = &timer_handler;
//  if (sigaction(SIGVTALRM, &sa, NULL) < 0) {
//    fprintf(stderr, "system error: sigaction error\n");
//    //TODO check how to exit
//    exit(1);
//  }
//
//  timer.it_value.tv_sec = quantum_usecs / 1000000;
//  timer.it_value.tv_usec = quantum_usecs % 1000000;
//  timer.it_interval.tv_sec = quantum_usecs / 1000000;
//  timer.it_interval.tv_usec = quantum_usecs % 1000000;
//  if (setitimer(ITIMER_VIRTUAL, &timer, NULL)) {
//    fprintf(stderr, "system error: setitimer error\n");
//    exit(1);
//  }

  threads[0] = {0, RUNNING, {}, {}, 1, 0};
  total_quantum_usecs = quantum_usecs;
  setup_timer ();
  return 0;
}

int uthread_spawn (thread_entry_point entry_point)
{
  if (entry_point == NULL)
  {
    fprintf (stderr, "thread library error: null entry_point\n");
    return -1;
  }

  // Ensure the total number of threads does not exceed MAX_THREAD_NUM
  if (threads.size () >= MAX_THREAD_NUM && available_ids.empty ())
  {
    fprintf (stderr, "thread library error: exceeded maximum number of threads\n");
    return -1;
  }
  int tid;
  if (!available_ids.empty ())
  {
    auto it = available_ids.begin ();
    tid = *it;
    available_ids.erase (it);
  }
  else
  {
    //TODO check if should add  + 1
    tid = threads.size ();
  }

  threads[tid] = {tid, READY, {}, {}, 0, 0};

  address_t sp =
      (address_t) threads[tid].stack + STACK_SIZE - sizeof (address_t);
  address_t pc = (address_t) entry_point;

  if (sigsetjmp(threads[tid].env, 1) == 0)
  {
    (threads[tid].env->__jmpbuf)[JB_SP] = translate_address (sp);
    (threads[tid].env->__jmpbuf)[JB_PC] = translate_address (pc);
    sigemptyset (&threads[tid].env->__saved_mask);
  }
  ready_queue.push_back (&threads[tid]);
  return tid;
}

int uthread_terminate (int tid)
{
  if (threads.find (tid) == threads.end ())
  {
    fprintf (stderr, "thread library error: no such thread\n");
    return -1;
  }

  if (tid == 0)
  {
    exit (0);
  }

  if (threads[tid].state == READY)
  {
    ready_queue.remove_if ([tid] (thread *t)
                           { return t->id == tid; });
  }

  threads.erase (tid);
  available_ids.insert (tid);
  if (tid == current_thread)
  {
    schedule ();
  }
  return 0;
}

int uthread_block (int tid)
{
  // Check if the thread with the given ID exists
  if (threads.find (tid) == threads.end ())
  {
    fprintf (stderr, "thread library error: no such thread\n");
    return -1;
  }

  // Ensure that the main thread (tid == 0) cannot be blocked
  if (tid == 0)
  {
    fprintf (stderr, "thread library error: cannot block main thread\n");
    return -1;
  }

  // If the thread is already in the BLOCKED state, do nothing
  if (threads[tid].state == BLOCKED)
  {
    return 0;
  }

  // Change the thread's state to BLOCKED
  threads[tid].state = BLOCKED;

  // If the thread is in the READY state, remove it from the ready queue
  if (tid != current_thread && threads[tid].state == READY)
  {
    ready_queue.remove_if ([tid] (thread *t)
                           { return t->id == tid; });
  }

  // If the thread blocks itself, schedule the next thread
  if (tid == current_thread)
  {
    schedule ();
  }

  return 0;
}

int uthread_resume (int tid)
{
  // Check if the thread with the given ID exists
  if (threads.find (tid) == threads.end ())
  {
    fprintf (stderr, "thread library error: no such thread\n");
    return -1;
  }

  // Get a reference to the thread
  thread &t = threads[tid];

  // If the thread is in the RUNNING or READY state, do nothing
  if (t.state == RUNNING || t.state == READY)
  {
    return 0;
  }

  // If the thread is in the BLOCKED state, move it to the READY state and add it to the ready queue
  if (t.state == BLOCKED && t.sleep_quantums == 0)
  {
    t.state = READY;
    ready_queue.push_back (&t);
  }

  return 0;
}

int uthread_sleep (int num_quantums)
{
  // Validate the input parameter
  if (num_quantums <= 0)
  {
    fprintf (stderr, "thread library error: non-positive num_quantums\n");
    return -1;
  }

  // Ensure the main thread (tid == 0) cannot be put to sleep
  if (current_thread == 0)
  {
    fprintf (stderr, "thread library error: cannot put main thread to sleep\n");
    return -1;
  }

  // Block the running thread and set it to sleep for the specified number of quantums
  thread &t = threads[current_thread];
  t.sleep_quantums = num_quantums;

  // Move the thread to the sleeping threads list
  sleeping_threads[current_thread] = &t;

  // Block the current running thread
  if (uthread_block (current_thread) != 0)
  {
    return -1;
  }

  return 0;
}
